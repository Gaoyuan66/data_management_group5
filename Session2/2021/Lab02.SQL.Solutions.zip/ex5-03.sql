DELETE FROM terms
WHERE terms_id = 6